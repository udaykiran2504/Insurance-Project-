create database pj;
use pj;
select * from brokerege;
select * from fees;
select * from invoice;
select * from oppty;
select * from meeting;
select * from budget;


#KPI's
#total budget
select sum(new_budget)+ sum(cross_sell_bugdet)+sum(renewal_budget) total_budget from budget;

#new, renweal , cross sell budget

select sum(new_budget) new_budget , sum(cross_sell_bugdet) cross_sell_budget, sum(renewal_budget) renewal_budget
 from budget;
 
 select sum(amount) from invoice;
 select sum(amount) from fees;
 select sum(amount) from brokerage;
 
 # total achieved 
 select  
 (select sum(amount) from fees)+
(select sum(amount) from invoice)+
(select sum(amount) from brokerage)
total_achieved ;

#new invoice achieved percentage 
select concat( round((select sum(amount) from invoice 
where income_class = 'new') / 
(select sum(new_budget) from budget ) * 100  ),'%')new_invoice_achieved; 

#renewal invoiced achieved percentage 
select concat( round((select sum(amount) from invoice 
where income_class = 'renewal') / 
(select sum(renewal_budget) from budget ) * 100  ),'%')renewal_invoice_achieved; 

#cross sell invoiced achieved percentage 
select concat( round((select sum(amount) from invoice 
where income_class = 'cross sell') / 
(select sum(cross_sell_bugdet) from budget ) * 100  ),'%')cross_sell_invoice_achieved; 





# no of meetings by account executive
SELECT 
    Account_Executive,
    COUNT(*) AS total_meetings
FROM meeting
GROUP BY Account_Executive
ORDER BY total_meetings DESC;
 
 # yearly meeting count

SELECT 
    YEAR(STR_TO_DATE(meeting_date, '%d-%m-%Y')) AS meeting_year,
    COUNT(account_executive) AS meeting_count
FROM meeting
GROUP BY meeting_year
ORDER BY meeting_year;

ALTER TABLE invoice 
RENAME COLUMN `account executive` TO account_executive;


# no of invoices by account executive
SELECT 
    IFNULL(account_executive, 'Grand Total') AS account_executive,
    SUM(CASE WHEN income_class = 'Cross Sell' THEN 1 ELSE 0 END) AS Cross_Sell,
    SUM(CASE WHEN income_class = 'New' THEN 1 ELSE 0 END) AS New_Business,
    SUM(CASE WHEN income_class = 'Renewal' THEN 1 ELSE 0 END) AS Renewal,
    COUNT(*) AS Grand_Total
FROM invoice
GROUP BY account_executive WITH ROLLUP
ORDER BY 
    CASE WHEN account_executive IS NULL THEN 1 ELSE 0 END,  -- pushes NULL (Grand Total) last
    Grand_Total DESC;
    
    # stage funnel by revenue     
SELECT stage,
SUM(revenue_amount) AS total_revenue
FROM oppty
GROUP BY stage
ORDER BY total_revenue DESC;

#top 5 opportunities by revenue 

select opportunity_name as name , revenue_amount as revenue 
from oppty order by revenue desc  limit 5;

#top 5 open opportunities by revenue 

select opportunity_name name , revenue_amount as revenue 
 from oppty 
 where stage <> 'negotiate'
 limit 5;
 
#product grpup by product distrudution 

select product_group group_name,  count( opportunity_name ) count
from oppty 
group by 1  order by count desc;



